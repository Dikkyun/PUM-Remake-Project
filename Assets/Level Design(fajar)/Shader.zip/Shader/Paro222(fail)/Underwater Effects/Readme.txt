Upgrading from URP 2021.2
Fixing issues with the new URP version.
The script for the renderer feature is primarily based on the examples provided in the following websites: 

https://www.cyanilux.com/tutorials/custom-renderer-features/
https://samdriver.xyz/article/scriptable-render

Additionally, if you wish to apply this effect to your game or video, please inform me in advance. Thank you for your cooperation.
Discord : paro456d